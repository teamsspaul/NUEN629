.. _gallery-material-library:

Material Library
===================

Download the :download:`full notebook <../../examples/material_library.ipynb>`.

.. notebook:: ../../examples/material_library.ipynb
