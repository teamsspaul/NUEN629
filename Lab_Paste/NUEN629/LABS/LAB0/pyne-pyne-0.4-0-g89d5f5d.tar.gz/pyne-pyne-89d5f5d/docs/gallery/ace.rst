.. _gallery-ace:

ACE Reader
==============

Download the :download:`full notebook <../../examples/ace.ipynb>`.

.. notebook:: ../../examples/ace.ipynb
