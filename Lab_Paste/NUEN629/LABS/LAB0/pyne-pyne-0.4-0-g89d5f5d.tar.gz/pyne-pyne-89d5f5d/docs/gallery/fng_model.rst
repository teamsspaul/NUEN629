.. _gallery-fng-model:

FNG Model
==============

Download the :download:`full notebook <../../examples/fng_model.ipynb>`.

.. notebook:: ../../examples/fng_model.ipynb
