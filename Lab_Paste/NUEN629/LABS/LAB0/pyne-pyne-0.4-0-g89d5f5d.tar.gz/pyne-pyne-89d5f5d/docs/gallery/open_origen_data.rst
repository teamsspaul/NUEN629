.. _gallery-open-origen-data.:

Open ORIGEN Data
=================

Download the :download:`full notebook <../../examples/open_origen_data.ipynb>`.

.. notebook:: ../../examples/open_origen_data.ipynb
