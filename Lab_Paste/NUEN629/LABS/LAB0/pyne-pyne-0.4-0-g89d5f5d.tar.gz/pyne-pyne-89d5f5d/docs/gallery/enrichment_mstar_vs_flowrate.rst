.. _gallery-enrichment-mstar-vs-flowrate:

Erichment: M* vs Flowrate
==========================

Download the :download:`full notebook <../../examples/enrichment_mstar_vs_flowrate.ipynb>`.

.. notebook:: ../../examples/enrichment_mstar_vs_flowrate.ipynb
