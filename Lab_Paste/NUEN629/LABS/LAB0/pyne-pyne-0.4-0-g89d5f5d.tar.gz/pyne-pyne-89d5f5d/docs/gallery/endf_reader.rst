.. _gallery-endf_reader:

ENDF Reader
==============

Download the :download:`full notebook <../../examples/endf_reader.ipynb>`.

.. notebook:: ../../examples/endf_reader.ipynb
