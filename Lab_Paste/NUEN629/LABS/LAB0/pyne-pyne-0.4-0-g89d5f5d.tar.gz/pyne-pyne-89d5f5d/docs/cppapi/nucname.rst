Nuclide Naming -- ``libpyne_nucname``
=====================================

.. autodoxygenindex:: nucname.h
    :source: pyne_nucname

