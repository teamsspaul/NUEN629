.. _pyne_transmute_channels:

====================================================
Chain Solve -- :mod:`pyne.transmute.chainsolve`
====================================================

.. automodule:: pyne.transmute.chainsolve
    :members:
    :member-order: bysource
