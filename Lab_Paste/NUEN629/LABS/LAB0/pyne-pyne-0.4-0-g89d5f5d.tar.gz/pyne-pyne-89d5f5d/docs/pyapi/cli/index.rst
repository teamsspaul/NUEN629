.. _pyne_cli:

==========================================
Command Line Interfaces -- :mod:`pyne.cli`
==========================================
PyNE provides a number of command line interfaces into its libraries.  This 
sub-package is where those CLIs are primarily implemented.

.. toctree::
    :maxdepth: 1

    tape9
