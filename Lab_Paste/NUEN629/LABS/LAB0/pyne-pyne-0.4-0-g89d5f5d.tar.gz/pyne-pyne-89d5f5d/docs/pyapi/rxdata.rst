.. _pyne_dbgen_rxdata:

=================================================
Reaction Data -- :mod:`pyne.rxdata`
=================================================

.. automodule:: pyne.rxdata
    :members:
