.. _pyne_dbgen_wimsdfpy:

==================================================================
WIMSD Fission Product Yields -- :mod:`pyne.dbgen.wimsdfpy`
==================================================================

.. automodule:: pyne.dbgen.wimsdfpy
    :members:
