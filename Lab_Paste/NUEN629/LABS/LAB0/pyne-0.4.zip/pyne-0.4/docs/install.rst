Installation Instructions
=========================

.. include:: ../readme.rst
    :start-after: .. install-start
    :end-before: .. install-end
