.. _gallery-half-life:

Half Life Plot
==============

Download the :download:`full notebook <../../examples/half_life_plot.ipynb>`.

.. notebook:: ../../examples/half_life_plot.ipynb
