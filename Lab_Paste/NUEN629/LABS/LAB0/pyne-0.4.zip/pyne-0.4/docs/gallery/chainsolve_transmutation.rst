.. _gallery-chainsolve-transmutation:

Chainsolve Transmutation
========================

Download the :download:`full notebook <../../examples/chainsolve_transmutation.ipynb>`.

.. notebook:: ../../examples/chainsolve_transmutation.ipynb
