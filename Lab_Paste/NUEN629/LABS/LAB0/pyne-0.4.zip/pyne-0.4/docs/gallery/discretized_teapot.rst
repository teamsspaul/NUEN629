.. _gallery-discretized-teapot:

Discretized Teapot
==================

Download the :download:`full notebook <../../examples/discretized_teapot.ipynb>`.

.. notebook:: ../../examples/discretized_teapot.ipynb
