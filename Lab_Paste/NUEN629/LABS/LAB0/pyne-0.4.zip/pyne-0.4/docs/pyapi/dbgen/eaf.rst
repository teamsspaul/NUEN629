.. _pyne_dbgen_eaf:

=================================================
EAF -- :mod:`pyne.dbgen.eaf`
=================================================

.. automodule:: pyne.dbgen.eaf
    :members:

