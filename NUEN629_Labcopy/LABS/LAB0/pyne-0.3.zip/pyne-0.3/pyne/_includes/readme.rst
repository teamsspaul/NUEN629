NOTICE!
=======
This directory has been copied from Cython v0.17+ to expose functionality back to
folks using earlier versions Cython.  This allows PyNE to be installed natively
on a wider variety of systems.  This directory is beholden to the copyright and 
license listed, which is distinct from the license for the rest of PyNE.  This
directory is considered temporary and will likely be removed once Cython v0.17+
becomes the standard version(s).  Please see http://cython.org/ for more details.
