.. _simplesim_ex_raddetect:

===========================
Radiation detection example
===========================

Not created yet!
