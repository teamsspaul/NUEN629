.. _usersguide_mcnp:

====
MCNP
====

.. currentmodule:: pyne.mcnp

The library reference page for this module is located at :ref:`pyne_mcnp`.

There is some MCNP functionality, for generating MCNP inputs, at
:ref:`usersguide_simplesim`.
