Previous Versions
==================
The following are notes for and links to previously released versions of PyNE:

.. toctree::
    :maxdepth: 1

    0.3_release_notes
    0.2_release_notes
    0.1_release_notes

======= ========== ============== ==============
Version Date       Zip            Tar
======= ========== ============== ==============
0.3     10-31-2012 `zip 0.3`_     `tar 0.3`_
0.2-rc  11-08-2012 `zip 0.2-rc`_  `tar 0.2-rc`_
0.1     05-05-2012 `zip 0.1`_     `tar 0.1`_
0.1-rc  04-22-2012 `zip 0.1-rc`_  `tar 0.1-rc`_
======= ========== ============== ==============

.. _zip 0.3: https://github.com/pyne/pyne/zipball/0.3
.. _tar 0.3: https://github.com/pyne/pyne/tarball/0.3
.. _zip 0.2-rc: https://github.com/pyne/pyne/zipball/0.2-rc
.. _tar 0.2-rc: https://github.com/pyne/pyne/tarball/0.2-rc
.. _zip 0.1: https://github.com/pyne/pyne/zipball/0.1
.. _tar 0.1: https://github.com/pyne/pyne/tarball/0.1
.. _zip 0.1-rc: https://github.com/pyne/pyne/zipball/0.1-rc
.. _tar 0.1-rc: https://github.com/pyne/pyne/tarball/0.1-rc

