References & Publications
==========================
Publications using PyNE!

Download the :download:`bibtex file here <pynepubs.bib>`.

.. note::

    If you have published on, or know of any publications which use, PyNE
    please send the reference information to the :ref:`dev_team` or create
    a pull request on GitHub.

.. bibtex:: pynepubs.bib
