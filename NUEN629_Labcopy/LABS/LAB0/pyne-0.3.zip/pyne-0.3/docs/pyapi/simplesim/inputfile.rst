.. _pyne_simplesim_inputfile:

====================================================
Input File Module -- :mod:`pyne.simplesim.inputfile`
====================================================

.. automodule:: pyne.simplesim.inputfile
    :members:

