.. _pyne_simplesim_nestedgeom:

===================================================
Nested Geometry -- :mod:`pyne.simplesim.nestedgeom`
===================================================

.. currentmodule:: pyne.simplesim.nestedgeom

.. automodule:: pyne.simplesim.nestedgeom
    :member-order: 'bysource'
    :members:

