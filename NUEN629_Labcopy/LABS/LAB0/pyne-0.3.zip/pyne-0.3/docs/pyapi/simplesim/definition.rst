.. _pyne_simplesim_definition:

=====================================================
Definition Module -- :mod:`pyne.simplesim.definition`
=====================================================

.. currentmodule:: pyne.simplesim.definition

.. automodule:: pyne.simplesim.definition
    :members:

