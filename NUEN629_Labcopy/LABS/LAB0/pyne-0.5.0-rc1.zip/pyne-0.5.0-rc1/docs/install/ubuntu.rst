.. _ubuntu:

=================================
Ubuntu build script
=================================

A script for installing PyNE and all its dependencies from scratch on Ubuntu
14.04 - 14.10 is found `here
<https://github.com/pyne/install_scripts/blob/master/ubuntu_14.04.sh>`_
