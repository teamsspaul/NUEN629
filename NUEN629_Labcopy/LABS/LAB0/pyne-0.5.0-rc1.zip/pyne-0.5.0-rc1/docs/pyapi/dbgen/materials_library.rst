.. _pyne_dbgen_materials_library:

=========================================================
Materials Library -- :mod:`pyne.dbgen.materials_library`
=========================================================

.. automodule:: pyne.dbgen.materials_library
    :members:

