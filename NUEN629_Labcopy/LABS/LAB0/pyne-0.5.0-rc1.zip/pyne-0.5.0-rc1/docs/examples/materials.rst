.. _gallery-materials:

Materials
==============

Download the :download:`full notebook <../../examples/materials.ipynb>`.

.. notebook:: ../../examples/materials.ipynb
