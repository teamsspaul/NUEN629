.. _gallery-reaction-names:

Reaction Names
==============

Download the :download:`full notebook <../../examples/reaction_names.ipynb>`.

.. notebook:: ../../examples/reaction_names.ipynb
