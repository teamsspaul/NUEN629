.. _gallery-origen22-h1-xs:

Origen 2.2: H1 Cross Section
==============================

Download the :download:`full notebook <../../examples/origen22_h1_xs.ipynb>`.

.. notebook:: ../../examples/origen22_h1_xs.ipynb
