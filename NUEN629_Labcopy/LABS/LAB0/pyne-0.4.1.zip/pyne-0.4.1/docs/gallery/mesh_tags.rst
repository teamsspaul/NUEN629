.. _gallery-mesh-tags:

Mesh Tagging
==================

Download the :download:`full notebook <../../examples/mesh_tags.ipynb>`.

.. notebook:: ../../examples/mesh_tags.ipynb
