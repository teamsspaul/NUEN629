.. _pyne_transmute:

=========================================
Transmutation -- :mod:`pyne.transmute`
=========================================
The transmute sub-package adds transmutation routines for PyNE.

**Transmutation Modules**

.. toctree::
    :maxdepth: 1

    chainsolve
